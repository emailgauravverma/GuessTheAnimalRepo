using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GTAUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
